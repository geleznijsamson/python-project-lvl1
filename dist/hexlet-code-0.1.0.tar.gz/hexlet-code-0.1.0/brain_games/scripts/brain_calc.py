from brain_games import engine
from brain_games.games import calc


def main():
    engine.structure(calc.calculation, calc.head)


if __name__ == '__main__':
    main()
