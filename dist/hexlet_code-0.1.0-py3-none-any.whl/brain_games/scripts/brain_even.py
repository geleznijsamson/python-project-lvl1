from brain_games import even


def main():
    even.game()


if __name__ == '__main__':
    main()
