from brain_games import engine
from brain_games.games import gcd


def main():
    engine.structure(gcd.calculation, gcd.head)


if __name__ == '__main__':
    main()
